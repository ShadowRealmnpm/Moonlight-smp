# Dedipass Payment (Plugin)

[![Style](https://github.styleci.io/repos/237846477/shield)](https://github.styleci.io/repos/237846477)
[![Chat](https://img.shields.io/discord/625774284823986183?color=5865f2&label=Discord&logo=discord&logoColor=fff&style=flat-square)](https://azuriom.com/discord)

Plugin to add Dedipass to the shop's payment methods.
