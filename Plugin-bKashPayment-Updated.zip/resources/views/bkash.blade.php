
@extends('layouts.app')

@section('content')
<div class="container">
    <div class="card shadow p-4 rounded-3">
        <h3 class="mb-3">Enter Transaction ID</h3>
        <form method="POST" action="{{ route('bkash.verify') }}">
            @csrf
            <div class="mb-3">
                <input type="text" name="transaction_id" class="form-control" placeholder="Enter Transaction ID" required>
            </div>
            <p>Go to your BKASH Mobile Menu by dialing *247# or using the BKASH App.</p>
            <ul>
                <li>Choose: <strong>"Send Money"</strong></li>
                <li>Enter the Receiver Account Number: <strong>01988006661</strong></li>
                <li>Enter the amount: <strong>৳51</strong></li>
                <li>Confirm with your PIN.</li>
                <li>Enter the <strong>Transaction ID</strong> you receive in the box above and press <strong>VERIFY</strong></li>
            </ul>
            <button type="submit" class="btn btn-primary mt-3">VERIFY</button>
        </form>
    </div>
</div>
@endsection
