<?php

return [
    'setup' => 'Sur le panel Dedipass, vous devez sélectionner monnaie virtuelle, définir l\'URL d\'installation sur :url puis choisir Callback IPN et définir l\'URL de Callback sur :ipn. Vous pouvez configurer les offres sur le panel Dedipass. À noter également que les codes de test de Dedipass donne toujours 1 :money.',

    'keys' => 'Obtenir les clés',

    'site_money' => 'Du au fonctionnement de Dedipass, afin qu\'il puisse fonctionner, vous devez activer les achats avec l\'argent du site dans les <a href=":url">paramètres de la boutique</a>.',
];
