<?php

return [
    'setup' => 'On the Dedipass dashboard you need to select virtual currency, set the installation URL to :url then choose IPN callback and set the callback URL to :ipn. You can configure the offers on the Dedipass dashboard.',

    'keys' => 'Get the keys',

    'site_money' => 'In order to Dedipass to work, you must enable purchases with the site\'s money in the <a href=":url">shop\'s settings</a>.',
];
